<?php
    $kingStar = array(
        array(
                'name'=>'艾琳',
                'path'=>'img/艾琳.png'
            ),array(
                'name'=>'安琪拉',
                'path'=>'img/安琪拉.png'
            ),array(
                'name'=>'白起',
                'path'=>'img/白起.png'
            ),array(
                'name'=>'扁鹊',
                'path'=>'img/扁鹊.png'
            ),array(
                'name'=>'不知火舞',
                'path'=>'img/不知火舞.png'
            ),array(
                'name'=>'蔡文姬',
                'path'=>'img/蔡文姬.png'
            ),array(
                'name'=>'曹操',
                'path'=>'img/曹操.png'
            ),array(
                'name'=>'成吉思汗',
                'path'=>'img/成吉思汗.png'
            ),array(
                'name'=>'程咬金',
                'path'=>'img/程咬金.png'
            ),array(
                'name'=>'池暝头像',
                'path'=>'img/池暝头像.png'
            ),array(
                'name'=>'达摩',
                'path'=>'img/达摩.png'
            ),array(
                'name'=>'大乔',
                'path'=>'img/大乔.png'
            ),array(
                'name'=>'狄仁杰',
                'path'=>'img/狄仁杰.png'
            ),array(
                'name'=>'典韦',
                'path'=>'img/典韦.png'
            ),array(
                'name'=>'东皇太一',
                'path'=>'img/东皇太一.png'
            ),array(
                'name'=>'干将莫邪',
                'path'=>'img/干将莫邪.png'
            ),array(
                'name'=>'高渐离',
                'path'=>'img/高渐离.png'
            ),array(
                'name'=>'宫本武藏',
                'path'=>'img/宫本武藏.png'
            ),array(
                'name'=>'孤头像',
                'path'=>'img/孤头像.png'
            ),array(
                'name'=>'关羽',
                'path'=>'img/关羽.png'
            ),array(
                'name'=>'韩信',
                'path'=>'img/韩信.png'
            ),array(
                'name'=>'后羿',
                'path'=>'img/后羿.png'
            ),array(
                'name'=>'花木兰',
                'path'=>'img/花木兰.png'
            ),array(
                'name'=>'坏坏',
                'path'=>'img/坏坏.jpg'
            ),array(
                'name'=>'黄忠',
                'path'=>'img/黄忠.png'
            ),array(
                'name'=>'姜子牙',
                'path'=>'img/姜子牙.png'
            ),array(
                'name'=>'荆轲',
                'path'=>'img/荆轲.png'
            ),array(
                'name'=>'兰陵王',
                'path'=>'img/兰陵王.png'
            ),array(
                'name'=>'老夫子',
                'path'=>'img/老夫子.png'
            ),array(
                'name'=>'李白',
                'path'=>'img/李白.png'
            ),array(
                'name'=>'李元芳',
                'path'=>'img/李元芳.png'
            ),array(
                'name'=>'林家小仔头像',
                'path'=>'img/林家小仔头像.png'
            ),array(
                'name'=>'刘邦',
                'path'=>'img/刘邦.png'
            ),array(
                'name'=>'刘备',
                'path'=>'img/刘备.png'
            ),array(
                'name'=>'鲁班七号',
                'path'=>'img/鲁班七号.png'
            ),array(
                'name'=>'露娜',
                'path'=>'img/露娜.png'
            ),array(
                'name'=>'吕布',
                'path'=>'img/吕布.png'
            ),array(
                'name'=>'马可波罗',
                'path'=>'img/马可波罗.png'
            ),array(
                'name'=>'墨子',
                'path'=>'img/墨子.png'
            ),array(
                'name'=>'墨斐3',
                'path'=>'img/墨斐3.png'
            ),array(
                'name'=>'哪吒',
                'path'=>'img/哪吒.png'
            ),array(
                'name'=>'娜可露露',
                'path'=>'img/娜可露露.png'
            ),array(
                'name'=>'牛魔',
                'path'=>'img/牛魔.png'
            ),array(
                'name'=>'孙尚香',
                'path'=>'img/孙尚香.png'
            ),array(
                'name'=>'孙悟空',
                'path'=>'img/孙悟空.png'
            ),array(
                'name'=>'孙膑',
                'path'=>'img/孙膑.png'
            ),array(
                'name'=>'太乙真人',
                'path'=>'img/太乙真人.png'
            ),array(
                'name'=>'王昭君',
                'path'=>'img/王昭君.png'
            ),array(
                'name'=>'武则天',
                'path'=>'img/武则天.png'
            ),array(
                'name'=>'夏侯惇',
                'path'=>'img/夏侯惇.png'
            ),array(
                'name'=>'项羽',
                'path'=>'img/项羽.png'
            ),array(
                'name'=>'小乔',
                'path'=>'img/小乔.png'
            ),array(
                'name'=>'雅典娜',
                'path'=>'img/雅典娜.png'
            ),array(
                'name'=>'亚瑟',
                'path'=>'img/亚瑟.png'
            ),array(
                'name'=>'杨戬',
                'path'=>'img/杨戬.png'
            ),array(
                'name'=>'一点一横六',
                'path'=>'img/一点一横六.png'
            ),array(
                'name'=>'一叶落头像',
                'path'=>'img/一叶落头像.png'
            ),array(
                'name'=>'虞姬',
                'path'=>'img/虞姬.png'
            ),array(
                'name'=>'张飞',
                'path'=>'img/张飞.png'
            ),array(
                'name'=>'张良',
                'path'=>'img/张良.png'
            ),array(
                'name'=>'赵云',
                'path'=>'img/赵云.png'
            ),array(
                'name'=>'甄姬',
                'path'=>'img/甄姬.png'
            ),array(
                'name'=>'钟无艳',
                'path'=>'img/钟无艳.png'
            ),array(
                'name'=>'钟馗',
                'path'=>'img/钟馗.png'
            ),array(
                'name'=>'周瑜',
                'path'=>'img/周瑜.png'
            ),array(
                'name'=>'诸葛亮',
                'path'=>'img/诸葛亮.png'
            ),array(
                'name'=>'庄周',
                'path'=>'img/庄周.png'
            ),array(
                'name'=>'芈月',
                'path'=>'img/芈月.png'
            ),array(
                'name'=>'嬴政',
                'path'=>'img/嬴政.png'
            ),array(
                'name'=>'妲己',
                'path'=>'img/妲己.png'
            ),array(
                'name'=>'橘右京',
                'path'=>'img/橘右京.png'
            ),array(
                'name'=>'蝮蛇头像',
                'path'=>'img/蝮蛇头像.png'
            ),array(
                'name'=>'貂蝉',
                'path'=>'img/貂蝉.png'
            ),
    );
    // print_r($kingStar);
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>静态网站</title>
  <style type="text/css">
    html,
    body,
    div,
    ul,
    img {
      padding: 0;
      margin: 0;
    }

    header {
      background: lightgreen;
      height: 50px;
      text-align: center;
      line-height: 50px;
      font: bold 24px/50px Arial;
    }

    nav {
      background: lightblue;
      height: 30px;
      line-height: 30px;
      padding-left: 180px;
    }

    section {
      background: lightyellow;
      min-height: 600px;
    }

    footer {
      background: lightgray;
      height: 50px;
      text-align: center;
      line-height: 50px;
    }

    #container {
      width: 1010px;
      height: auto;
      margin: auto;
      background: #E2F9AA;
      padding-bottom: 10px;
    }

    ul li {
      list-style: none;
      width: 190px;
      height: 200px;
      float: left;
      background: lightyellow;
      margin-left: 10px;
      margin-top: 10px;
    }

    ul li img {
      width: 190px;
      height: 170px;
      display: block;
      cursor: pointer;
    }

    ul li div {
      background: #7DBD50;
      width: 185px;
      height: 30px;
      line-height: 30px;
      padding-left: 5px;
    }

    a {
      text-decoration: none;
      text-align: center;
    }
  </style>
</head>

<body>
  <header>王者农药商店</header>
  <nav>
    <a href="./index.php">男英雄</a>
    <a href="./index.php">女英雄</a>
    <a href="./index.php">不确定性别英雄</a>
  </nav>
  <section>
    <div id="container">
      <ul>
      <?php for($i=0;$i<count($kingStar);$i++){ ?>
          <li>
            <a href="detail/detail1.php?flag=banana">
            <img src="<?php echo $kingStar[$i]['path']; ?>">
            <div><?php echo $kingStar[$i]['name']; ?></div>
          </a>
        </li>
      <?php } ?>

      </ul>
      <div style="clear: both;"></div>
    </div>
  </section>
  <footer>版权所有</footer>
</body>

</html>