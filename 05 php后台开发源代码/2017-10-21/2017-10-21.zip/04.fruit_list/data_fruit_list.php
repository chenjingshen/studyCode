<?php
// 定义数组
$arr = array();
// 动态为数组添加内容
$arr[] = array('href' => 'detail/detail1.php?flag=banana','path' => 'img/banana1.jpg','name' => '香蕉');
$arr[] = array('href' => 'detail/detail1.php?flag=apple','path' => 'img/apple1.jpg','name' => '苹果');
$arr[] = array('href' => 'detail/detail1.php?flag=orange','path' => 'img/orange1.jpg','name' => '橘子');
$arr[] = array('href' => 'detail/detail1.php?flag=pineapple','path' => 'img/pineapple1.jpg','name' => '菠萝');
$arr[] = array('href' => 'detail/detail1.php?flag=mango','path' => 'img/mango1.jpg','name' => '芒果');
$arr[] = array('href' => 'detail/detail1.php?flag=grape','path' => 'img/grape1.jpg','name' => '葡萄');
$arr[] = array('href' => 'detail/detail1.php?flag=pomelo','path' => 'img/pomelo1.jpg','name' => '柚子');
$arr[] = array('href' => 'detail/detail1.php?flag=pawpaw','path' => 'img/pawpaw1.jpg','name' => '木瓜');
$arr[] = array('href' => 'detail/detail1.php?flag=kivi','path' => 'img/kivi1.jpg','name' => '猕猴桃');
$arr[] = array('href' => 'detail/detail1.php?flag=persimmon','path' => 'img/persimmon1.jpg','name' => '柿子');
$arr[] = array('href' => 'detail/detail1.php?flag=lemon','path' => 'img/lemon1.jpg','name' => '柠檬');
$arr[] = array('href' => 'detail/detail1.php?flag=pomegranate','path' => 'img/pomegranate1.jpg','name' => '石榴');
$arr[] = array('href' => 'detail/detail1.php?flag=pear','path' => 'img/pear1.jpg','name' => '梨');
$arr[] = array('href' => 'detail/detail1.php?flag=strawberry','path' => 'img/strawberry1.jpg','name' => '草莓');
$arr[] = array('href' => 'detail/detail1.php?flag=blueberry','path' => 'img/blueberry1.jpg','name' => '蓝莓');
$arr[] = array('href' => 'detail/detail1.php?flag=waxberry','path' => 'img/waxberry1.jpg','name' => '杨莓');
$arr[] = array('href' => 'detail/detail1.php?flag=peach','path' => 'img/peach1.jpg','name' => '桃');
$arr[] = array('href' => 'detail/detail1.php?flag=coconut','path' => 'img/coconut1.jpg','name' => '椰子');
$arr[] = array('href' => 'detail/detail1.php?flag=apricot','path' => 'img/apricot1.jpg','name' => '杏');
$arr[] = array('href' => 'detail/detail1.php?flag=cherry','path' => 'img/cherry1.jpg','name' => '樱桃');
?>